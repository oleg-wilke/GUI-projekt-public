#ifndef CUSTOMTABLEVIEWWITHMENUFORTABLETEST_H
#define CUSTOMTABLEVIEWWITHMENUFORTABLETEST_H

#include <QAction>
#include "customtableview.h"

class CustomTableViewWithMenuForTableTest : public CustomTableView
{
Q_OBJECT
public:
    CustomTableViewWithMenuForTableTest(QSqlRelationalTableModel *model);
    ~CustomTableViewWithMenuForTableTest();

public slots:
//    void setFilterEqual();
//    void setFilterUnequal();
//    void setFilterLess();
//    void setFilterMore();
//    void setFilterCancel();

private:
    QAction *actionFilterEqual;
    QAction *actionFilterUnequal;
    QAction *actionFilterLess;
    QAction *actionFilterMore;
    QAction *actionFilterCancel;

    QSqlRelationalTableModel *current_model;
};

#endif // CUSTOMTABLEVIEWWITHMENUFORTABLETEST_H
