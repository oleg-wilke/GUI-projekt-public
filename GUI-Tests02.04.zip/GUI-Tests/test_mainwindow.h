#ifndef TEST_MAINWINDOW_H
#define TEST_MAINWINDOW_H

#include <QMainWindow>
#include <QSql>
#include <QSqlDatabase>
#include <QSqlQuery>
// #include <QSqlTableModel>
#include <QTableView>
#include <QSqlRelationalTableModel>
#include <QSqlRelationalDelegate>

#include "customtableview.h"
#include "ui_mainwindow.h"
#include "customtableviewwithmenufortabletest.h"

#define DB_FILE "C:\\Qt Projekt\\gui_tests.db"
#define DB_DRIVER "QSQLITE"

class Test_MainWindow : public QMainWindow
{
public:
    Test_MainWindow(QSqlDatabase* database, QWidget *parent = nullptr);
    ~Test_MainWindow();
private slots:
    void on_pushButton_Schliessen_clicked();

private:
    void Testarten_init();
    void Tester_init();
    void Produkte_init();
    void Test_init();
    Ui::MainWindow *ui;
    QSqlDatabase* database;
    QSqlRelationalTableModel *modelTester;
    QSqlRelationalTableModel *modelTestarten;
    QSqlRelationalTableModel *modelProdukte;
    QSqlRelationalTableModel *modelTest;
    CustomTableView *viewTester;
    CustomTableView *viewTestarten;
    CustomTableView *viewProdukte;
    CustomTableView *viewTest;
//    CustomTableViewWithMenuForTableTest *viewTest;
};

#endif // TEST_MAINWINDOW_H
