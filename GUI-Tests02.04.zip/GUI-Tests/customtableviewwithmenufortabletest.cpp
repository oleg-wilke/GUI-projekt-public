#include "customtableviewwithmenufortabletest.h"

CustomTableViewWithMenuForTableTest::CustomTableViewWithMenuForTableTest(QSqlRelationalTableModel *model)
    : CustomTableView(model)
{
//    current_model = model;
// s. 48 Summerfield
//    actionFilterEqual = new QAction(tr("Filter ="), this);
//    actionFilterUnequal = new QAction(tr("Filter !="), this);
//    actionFilterLess = new QAction(tr("Filter <="), this);
//    actionFilterMore = new QAction(tr("Filter >="), this);
//    actionFilterCancel = new QAction(tr("Filter auflösen"), this);

//    connect(actionFilterEqual, SIGNAL(triggered()), this, SLOT(setFilterEqual()));
//    connect(actionFilterUnequal, SIGNAL(triggered()), this, SLOT(setFilterUnequal()));
//    connect(actionFilterLess, SIGNAL(triggered()), this, SLOT(setFilterLess()));
//    connect(actionFilterMore, SIGNAL(triggered()), this, SLOT(setFilterMore()));
//    connect(actionFilterCancel, SIGNAL(triggered()), this, SLOT(setFilterCancel()));
}

CustomTableViewWithMenuForTableTest::~CustomTableViewWithMenuForTableTest()
{
//    delete actionFilterEqual;
//    delete actionFilterUnequal;
//    delete actionFilterLess;
//    delete actionFilterMore;
//    delete actionFilterCancel;
}

//void CustomTableViewWithMenuForTableTest::setFilterEqual()
//{
//    current_model->setFilter("date_of_test = '22.12.2020'");
//}

//void CustomTableViewWithMenuForTableTest::setFilterUnequal()
//{
//    current_model->setFilter("date_of_test != '22.12.2020'");
//}

//void CustomTableViewWithMenuForTableTest::setFilterLess()
//{
//    current_model->setFilter("date_of_test <= '22.12.2020'");
//}

//void CustomTableViewWithMenuForTableTest::setFilterMore()
//{
//    current_model->setFilter("date_of_test >= '22.12.2020'");
//}

//void CustomTableViewWithMenuForTableTest::setFilterCancel()
//{
//    current_model->setFilter("");
//}


