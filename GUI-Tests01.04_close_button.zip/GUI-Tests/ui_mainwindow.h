/********************************************************************************
** Form generated from reading UI file 'mainwindownSQzij.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef MAINWINDOWNSQZIJ_H
#define MAINWINDOWNSQZIJ_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_MainForm;
    QTabWidget *tabTabellen;
    QWidget *tabTest;
    QGridLayout *gridLayout_Test;
    QWidget *tabProdukt;
    QGridLayout *gridLayout_Produkt;
    QWidget *tabTester;
    QGridLayout *gridLayout_Tester;
    QWidget *tabTestarten;
    QGridLayout *gridLayout_Testarten;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_Schliessen;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(816, 606);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout_MainForm = new QGridLayout(centralwidget);
        gridLayout_MainForm->setObjectName(QString::fromUtf8("gridLayout_MainForm"));
        tabTabellen = new QTabWidget(centralwidget);
        tabTabellen->setObjectName(QString::fromUtf8("tabTabellen"));
        tabTest = new QWidget();
        tabTest->setObjectName(QString::fromUtf8("tabTest"));
        gridLayout_Test = new QGridLayout(tabTest);
        gridLayout_Test->setObjectName(QString::fromUtf8("gridLayout_Test"));
        tabTabellen->addTab(tabTest, QString());
        tabProdukt = new QWidget();
        tabProdukt->setObjectName(QString::fromUtf8("tabProdukt"));
        gridLayout_Produkt = new QGridLayout(tabProdukt);
        gridLayout_Produkt->setObjectName(QString::fromUtf8("gridLayout_Produkt"));
        tabTabellen->addTab(tabProdukt, QString());
        tabTester = new QWidget();
        tabTester->setObjectName(QString::fromUtf8("tabTester"));
        gridLayout_Tester = new QGridLayout(tabTester);
        gridLayout_Tester->setObjectName(QString::fromUtf8("gridLayout_Tester"));
        tabTabellen->addTab(tabTester, QString());
        tabTestarten = new QWidget();
        tabTestarten->setObjectName(QString::fromUtf8("tabTestarten"));
        gridLayout_Testarten = new QGridLayout(tabTestarten);
        gridLayout_Testarten->setObjectName(QString::fromUtf8("gridLayout_Testarten"));
        tabTabellen->addTab(tabTestarten, QString());

        gridLayout_MainForm->addWidget(tabTabellen, 0, 0, 1, 2);

        horizontalSpacer = new QSpacerItem(714, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_MainForm->addItem(horizontalSpacer, 1, 0, 1, 1);

        pushButton_Schliessen = new QPushButton(centralwidget);
        pushButton_Schliessen->setObjectName(QString::fromUtf8("pushButton_Schliessen"));

        gridLayout_MainForm->addWidget(pushButton_Schliessen, 1, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 816, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        tabTabellen->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        tabTabellen->setTabText(tabTabellen->indexOf(tabTest), QCoreApplication::translate("MainWindow", "Test", nullptr));
        tabTabellen->setTabText(tabTabellen->indexOf(tabProdukt), QCoreApplication::translate("MainWindow", "Produkt", nullptr));
        tabTabellen->setTabText(tabTabellen->indexOf(tabTester), QCoreApplication::translate("MainWindow", "Tester", nullptr));
        tabTabellen->setTabText(tabTabellen->indexOf(tabTestarten), QCoreApplication::translate("MainWindow", "Testarten", nullptr));
        pushButton_Schliessen->setText(QCoreApplication::translate("MainWindow", "Schliessen", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // MAINWINDOWNSQZIJ_H
