#include "customtableview.h"

CustomTableView::CustomTableView(QSqlRelationalTableModel *model)
{
    setModel(model);
    setSelectionMode(QAbstractItemView::SingleSelection);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    resizeColumnsToContents();
    setAlternatingRowColors(true);
    setSortingEnabled(true);

    QObject::connect(this, SIGNAL(delete_pressed(int)), this, SLOT(delete_row(int)));
}
//siehe s. 164 Summerfield Erklärung zur Funktion
void CustomTableView::keyReleaseEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Delete)
    {
        // https://www.qtcentre.org/threads/4885-Remove-selected-rows-from-a-QTableView
        QModelIndexList current_selection =  this->selectionModel()->selectedRows();
        if (!current_selection.empty())
        {
         // 0 weil wir nur eine row haben; row gibt zurück den index auf den er sich bezieht
            emit delete_pressed(current_selection.at(0).row());
        }
    }
    QTableView::keyReleaseEvent(event);
}

void CustomTableView::delete_row(int row)
{
    this->model()->removeRow(row);
// https://www.qtcentre.org/threads/25546-Hide-rows-from-QTableView-QSqlRelationalTableModel
    this->hideRow(row);

}
