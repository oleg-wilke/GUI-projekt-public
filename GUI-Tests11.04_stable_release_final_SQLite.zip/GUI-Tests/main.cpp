#include <QDialog>
#include <QApplication>
// Damit dieser header funktioniert muss man im pro-file QT += sql widgets eintragen
#include <QSql>
#include <QSqlDatabase>
#include <QMessageBox>
#include <QSqlError>


#include "test_mainwindow.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
// Erstellen von Objekt des Fensters

// Initialisieren der DB database
//    QSqlDatabase database = QSqlDatabase::addDatabase(DB_DRIVER);
    QSqlDatabase database = QSqlDatabase::addDatabase("QODBC");
    database.setHostName("localhost");
    database.setDatabaseName("Driver={MySQL ODBC 8.0 Unicode Driver};DATABASE=testingdb;");

    database.setUserName("root");
    database.setPassword("root");
    database.setPort(3306);

//    database.setDatabaseName("testingdb");

    //QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
    //    db.setHostName("127.0.0.1");
    //    db.setHostName("localhost");
    //    db.setDatabaseName("Driver={MySQL ODBC 8.0 Unicode Driver};DATABASE=testergebnissedb;");
    //    db.setUserName("root");
    //    db.setPassword("root");
    //
    if (!database.open())
    {
     //    return false;
        QMessageBox::critical(0, QObject::tr("Database Error"),
        database.lastError().text());
    }

// Übergeben von variable database
    Test_MainWindow ui;
    ui.show();

    return app.exec();
}

/*int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}*/


