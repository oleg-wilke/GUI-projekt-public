#include "customtablemodel.h"

customtablemodel::customtablemodel()
{

}
