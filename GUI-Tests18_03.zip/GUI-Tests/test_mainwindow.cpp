#include "test_mainwindow.h"


Test_MainWindow::Test_MainWindow(QSqlDatabase* database, QWidget *parent)
    : QMainWindow(parent)
{
    ui = new Ui::MainWindow;
    ui->setupUi(this);
// bekommen initialisierte DB
    this->database = database;
    QSqlQuery query;
    if (!query.exec("SELECT id FROM test_arten"))
    {
        query.exec("CREATE TABLE test_arten (id INTEGER PRIMARY KEY,"
                                             "test_name VARCHAR(40) NOT NULL,"
                                             "descr VARCHAR(255))");
        query.exec("INSERT INTO test_arten (test_name, descr) VALUES ('IO-Test', 'Input Output Test')");
        query.exec("INSERT INTO test_arten (test_name) VALUES ('RAM-Test')");
        query.exec("INSERT INTO test_arten (test_name, descr) VALUES ('Flash-Test', 'Testen des Flash Speichers')");
        query.exec("INSERT INTO test_arten (test_name) VALUES ('WAKE-UP')");
        query.exec("INSERT INTO test_arten (test_name) VALUES ('Download-Test')");
        query.exec("INSERT INTO test_arten (test_name) VALUES ('Analog-Test')");

        query.exec("CREATE TABLE tester (id INTEGER PRIMARY KEY,"
            "name VARCHAR(40) NOT NULL,"
            "descr VARCHAR(255))");
        query.exec("INSERT INTO tester (name, descr) VALUES ('Oleg', 'Azubi')");
        query.exec("INSERT INTO tester (name, descr) VALUES ('Alexander', 'Mitarbeiter')");
        query.exec("INSERT INTO tester (name, descr) VALUES ('David', 'aufpassen, wegen Fehlerhäufigkeit')");
    }

    Testarten_init();
    Tester_init();

}
// Summerfield s. 320
void Test_MainWindow::Testarten_init()
{
    modelTestarten.setTable("test_arten");
    modelTestarten.setEditStrategy(QSqlTableModel::OnRowChange);

    modelTestarten.setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    modelTestarten.setHeaderData(1, Qt::Horizontal, QObject::tr("Test Name"));
    modelTestarten.setHeaderData(2, Qt::Horizontal, QObject::tr("Descr"));

    modelTestarten.select();
    viewTestarten.setModel(&modelTestarten);
    viewTestarten.setSelectionMode(QAbstractItemView::SingleSelection);
    viewTestarten.setSelectionBehavior(QAbstractItemView::SelectRows);
    viewTestarten.resizeColumnsToContents();
    viewTestarten.setAlternatingRowColors(true);
    viewTestarten.setSortingEnabled(true);

    ui->gridLayout_Testarten->addWidget(&viewTestarten);
}

void Test_MainWindow::Tester_init()
{
    modelTester.setTable("tester");
    modelTester.setEditStrategy(QSqlTableModel::OnRowChange);

    modelTester.setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    modelTester.setHeaderData(1, Qt::Horizontal, QObject::tr("Name"));
    modelTester.setHeaderData(2, Qt::Horizontal, QObject::tr("Descr"));

    modelTester.select();
    viewTester.setModel(&modelTester);
    viewTester.setSelectionMode(QAbstractItemView::SingleSelection);
    viewTester.setSelectionBehavior(QAbstractItemView::SelectRows);
    viewTester.resizeColumnsToContents();
    viewTester.setAlternatingRowColors(true);
    viewTester.setSortingEnabled(true);

    ui->gridLayout_Tester->addWidget(&viewTester);
}

void Test_MainWindow::Produkte_init()
{
    modelProdukte.setTable("produkte");
    modelProdukte.setEditStrategy(QSqlTableModel::OnRowChange);

    modelProdukte.setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    modelProdukte.setHeaderData(1, Qt::Horizontal, QObject::tr("Produkt Name"));
    modelProdukte.setHeaderData(2, Qt::Horizontal, QObject::tr("Seriennummer"));
    modelProdukte.setHeaderData(0, Qt::Horizontal, QObject::tr("RAM Größe kb"));
    modelProdukte.setHeaderData(1, Qt::Horizontal, QObject::tr("Flash Größe kb"));
    modelProdukte.setHeaderData(2, Qt::Horizontal, QObject::tr("Uhr"));
    modelProdukte.setHeaderData(0, Qt::Horizontal, QObject::tr("Industrial"));

    modelProdukte.select();
    viewProdukte.setModel(&modelProdukte);
    viewProdukte.setSelectionMode(QAbstractItemView::SingleSelection);
    viewProdukte.setSelectionBehavior(QAbstractItemView::SelectRows);
    viewProdukte.resizeColumnsToContents();
    viewProdukte.setAlternatingRowColors(true);
    viewProdukte.setSortingEnabled(true);

    ui->gridLayout_Produkt->addWidget(&viewProdukte);
}

Test_MainWindow::~Test_MainWindow()
{
    delete ui;
}

//void Test_MainWindow::on_pushButton_Schliessen_clicked()
//{
//    QObject::connect(exit, SIGNAL(clicked()), qApp, SLOT(quit()));
//}
